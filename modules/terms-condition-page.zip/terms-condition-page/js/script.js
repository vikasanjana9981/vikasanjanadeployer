jQuery(document).ready(function(){
    /* ------------------------------------------------------------ */
    /* more Roaster Slider */
    /* ------------------------------------------------------------ */
    jQuery('.moreRoasterRow').slick({
        dots: true,
        infinite: false,
        speed: 300,
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows:false,
        autoplay: true,
        autoplaySpeed: 1200,
    });
    /* ------------------------------------------------------------ */
    /* Roaster List  Slider */
    /* ------------------------------------------------------------ */
    roasterHighlightProductSlider();
     function roasterHighlightProductSlider() {
         if (jQuery(window).width() <= 601) {
             /*Footer Block Mobile Slider*/
             jQuery('.roasterListRow').slick({
                dots: true,
                infinite: true,
                slidesToShow: 1,
                slidesToScroll: 1,
                arrows:false,
                autoplay: true,
                autoplaySpeed: 1200,
            });
         }
     }
});