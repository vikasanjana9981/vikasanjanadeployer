<?php

/**
 * @class    Terms Condition Page
 * @category Class
 * @author   Ganesh pawar
 * */
class TermsCondition {

    protected static $_instance = null;

    public static function get_instance() {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    public function __construct() {
        $this->hooks();
    }

    public function hooks() {
        add_action('wp_enqueue_scripts', array($this, 'enqueue_styles_scripts'));
        // add_shortcode('product_shortcode', array($this, 'product_shortcode_function'));
    }

    /* ----------------------------------------------------- */
    /* Enqueue stylesheets javascript only for this module only */
    /* ----------------------------------------------------- */
    public function enqueue_styles_scripts() {
        if (is_page('8')){
            /*  Style Sheets */
            wp_enqueue_style('terms_condition_style', get_stylesheet_directory_uri() . '/modules/terms-condition-page/css/style.css');
            wp_enqueue_style('terms_condition_responsive_style', get_stylesheet_directory_uri() . '/modules/terms-condition-page/css/responsive-style.css');

            /*  Java Scripts */
            wp_enqueue_script('terms_condition_script', get_stylesheet_directory_uri() . '/modules/terms-condition-page/js/script.js', array('jquery'));
        }
    }

    /* ----------------------------------------------------- */
    /* Get Banner Html */
    /* ----------------------------------------------------- */
    public function get_term_condition_html() {
        echo ck_helper_object()->ck_get_template('terms-condition.php', 'terms-condition-page', array(), true);
    }
    
} //end class

function terms_condition_page_object() {
    return TermsCondition::get_instance();
}

terms_condition_page_object();
